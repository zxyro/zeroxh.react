import "../Hero/hero.css";

export default function HeroSection({
  blurred = false,
  onCTAPrimary,
  onCTASecondary,
}) {
  return (
    <section
      id="hero"
      className={`hero-section ${blurred ? "hero-blur" : ""}`}
    >
      <div className="hero-container">
        {/* LEFT */}
        <div className="hero-left">
            <h1 className="hero-title">
              Jasa Desain <br /> Grafis Pemula
            </h1>

          <p className="hero-subtitle">
            design by siizeroo | With <h4>Alight Motion</h4>
            <p>Fokus pada visual yang rapi, konsep jelas,
            dan siap dipakai untuk kebutuhan real bisnis.</p>
          </p>

          <div className="hero-actions">
            <button
              className="btn btn-primary"
              onClick={onCTAPrimary}
            >
              Mulai Pesan Desain
            </button>

            <button
              className="btn btn-secondary"
              onClick={onCTASecondary}
            >
              Lihat Portfolio
            </button>
          </div>
        </div>

        {/* RIGHT */}
          <div className="hero-right">
            <div className="best-seller">
              <h3 className="best-seller-title">Paket Best Seller</h3>

              <div className="best-seller-grid">

                <div className="package-card">
                  <div className="package-header">
                    <h4>Desain Cover Buku</h4>
                    <div className="package-tags">
                      <span>Standard</span>
                      <span>3–4 Hari</span>
                    </div>
                  </div>

                  <div className="package-footer">
                    <div className="package-price">
                      <strong>Rp150.000</strong>
                      <span className="rating">★★★★★</span>
                    </div>
                    <button className="see-btn">Lihat Paket</button>
                  </div>
                </div>

                <div className="package-card">
                  <div className="package-header">
                    <h4>Desain Poster</h4>
                    <div className="package-tags">
                      <span>Standard</span>
                      <span>3–4 Hari</span>
                    </div>
                  </div>

                  <div className="package-footer">
                    <div className="package-price">
                      <strong>Rp100.000</strong>
                      <span className="rating">★★★★☆</span>
                    </div>
                    <button className="see-btn">Lihat Paket</button>
                  </div>
                </div>

              </div>
            </div>
          </div>

        </div>
      </section>
  );
}