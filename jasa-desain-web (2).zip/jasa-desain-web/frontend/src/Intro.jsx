import { useEffect, useState } from "react";

export default function Intro({ onFinish }) {
  const [hide, setHide] = useState(false);

  useEffect(() => {
    const timer1 = setTimeout(() => {
      setHide(true);
    }, 1500);

    const timer2 = setTimeout(() => {
      onFinish();
    }, 2000);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
    };
  }, [onFinish]);

  return (
    <div className={`intro ${hide ? "intro-hide" : ""}`}>
      <h1 className="intro-title">JASA DESAIN GRAFIS</h1>
      <p className="intro-sub">design by siizeroo</p>
    </div>
  );
}
