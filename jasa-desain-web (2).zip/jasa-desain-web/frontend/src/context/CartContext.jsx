import { createContext, useContext, useEffect, useState } from "react";

const CartContext = createContext();

const AVAILABLE_VOUCHERS = {
  DISKON10: { code: "DISKON10", type: "percent", value: 10 },
  POTONG50K: { code: "POTONG50K", type: "flat", value: 50000 },
};

export const CartProvider = ({ children }) => {
  
  const [items, setItems] = useState([]);
  const [voucher, setVoucher] = useState(null);
  const [voucherError, setVoucherError] = useState("");
  const [claimedVouchers, setClaimedVouchers] = useState([]);
  const [activeVoucher, setActiveVoucher] = useState(null);

  useEffect(() => {
    const storedItems =
      JSON.parse(localStorage.getItem("cart_items")) || [];
    const storedVouchers =
      JSON.parse(localStorage.getItem("claimed_vouchers")) || [];

    setItems(storedItems);
    setClaimedVouchers(storedVouchers);
  }, []);

  useEffect(() => {
    localStorage.setItem("cart_items", JSON.stringify(items));
  }, [items]);

  useEffect(() => {
    localStorage.setItem(
      "claimed_vouchers",
      JSON.stringify(claimedVouchers)
    );
  }, [claimedVouchers]);

  const totalQty = items.reduce((sum, i) => sum + i.qty, 0);

  const addItem = (item) => {
    setItems((prev) => {
      const existing = prev.find(
        (i) =>
          i.service === item.service &&
          i.package === item.package
      );

      if (existing) {
        return prev.map((i) =>
          i.id === existing.id
            ? { ...i, qty: i.qty + (item.qty || 1) }
            : i
        );
      }

      return [
        ...prev,
        {
          id: Date.now() + Math.random(),
          qty: item.qty || 1,
          requestNote: "",
          ...item,
        },
      ];
    });
  };

  const removeItem = (id) =>
    setItems((prev) => prev.filter((i) => i.id !== id));

  const updateItem = (id, data) =>
    setItems((prev) =>
      prev.map((i) => (i.id === id ? { ...i, ...data } : i))
    );

  const updateQty = (id, qty) => {
    if (qty < 1) return;
    updateItem(id, { qty });
  };

  const updateRequestNote = (id, note) =>
    updateItem(id, { requestNote: note });

  const subtotal = () =>
    items.reduce((sum, i) => sum + i.price * i.qty, 0);

  const discountAmount = () => {
    if (!activeVoucher) return 0;

    if (activeVoucher.type === "percent") {
      return Math.floor(
        (subtotal() * activeVoucher.value) / 100
      );
    }

    if (activeVoucher.type === "flat") {
      return Math.min(activeVoucher.value, subtotal());
    }

    return 0;
  };

  const finalPrice = () => subtotal() - discountAmount();

  const totalPrice = () => finalPrice(); 

  const claimVoucher = (code) => {
    const key = code.toUpperCase();
    const voucher = AVAILABLE_VOUCHERS[key];

    if (!voucher) {
      setVoucherError("Voucher tidak ditemukan");
      return false;
    }

    if (claimedVouchers.find((v) => v.code === key)) {
      setVoucherError("Voucher sudah diklaim");
      return false;
    }

    setClaimedVouchers((prev) => [...prev, voucher]);
    setVoucherError("");
    return true;
  };

  const applyVoucher = (code) => {
    const key = code.toUpperCase();
    const owned = claimedVouchers.find(
      (v) => v.code === key
    );

    if (!owned) {
      setVoucherError("Voucher belum diklaim");
      return false;
    }

    setActiveVoucher(owned);
    setVoucherError("");
    return true;
  };

  const removeVoucher = () => {
    setActiveVoucher(null);
    setVoucherError("");
  };

  const clearCart = () => {
    setItems([]);
    removeVoucher();
  };

  return (
    <CartContext.Provider
      value={{
        items,
        totalQty,

        addItem,
        removeItem,
        updateItem,
        updateQty,
        updateRequestNote,

        subtotal,
        discountAmount,
        finalPrice,
        voucher,
        totalPrice,

        claimedVouchers,
        activeVoucher,
        voucherError,

        claimVoucher,
        applyVoucher,
        removeVoucher,
        clearCart,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => useContext(CartContext);
