import { createContext, useContext, useEffect, useState } from "react";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const storedUser = localStorage.getItem("auth_user");
    if (storedUser) setUser(JSON.parse(storedUser));
    setIsLoading(false);
  }, []);

  const loginWithGoogle = () => {
    const googleUser = {
      uid: "google_" + Date.now(),
      name: "Google User",
      email: "user@gmail.com",
      photoURL:
        "https://ui-avatars.com/api/?name=Google+User&background=0D8ABC&color=fff",
      role: "user",
    };

    localStorage.setItem("auth_user", JSON.stringify(googleUser));
    setUser(googleUser);
  };

  const logout = () => {
    localStorage.removeItem("auth_user");
    setUser(null);
  };

  const isLoggedIn = !!user;
  const isGuest = !user;

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoggedIn,
        isGuest,
        isLoading,
        loginWithGoogle,
        logout,
      }}
    >
      {!isLoading && children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);