export const logoPackages = [
  {
    id: "basic",
    name: "Basic",
    price: 200000,
    features: [
      "1 konsep logo",
      "Revisi 2x",
      "File PNG & JPG"
    ]
  },
  {
    id: "standard",
    name: "Standard",
    price: 350000,
    features: [
      "2 konsep logo",
      "Revisi 5x",
      "File PNG, JPG, SVG"
    ],
    popular: true
  },
  {
    id: "premium",
    name: "Premium",
    price: 500000,
    features: [
      "3 konsep logo",
      "Revisi unlimited",
      "Semua format + brand guide"
    ]
  }
];
