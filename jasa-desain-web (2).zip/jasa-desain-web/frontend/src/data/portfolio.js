const PORTFOLIO = {
  poster: [
    { image: "portfolio/poster/poster1-nike.png", title: "Poster Event", desc: "Visual promosi dengan fokus konversi" },
    { image: "portfolio/poster/poster2-kamenraider.png", title: "Poster Produk", desc: "Bold headline & hierarchy jelas" },
    { image: "portfolio/poster/poster3-NewJeans.png", title: "Poster Produk", desc: "Bold headline & hierarchy jelas" },
    { image: "portfolio/poster/poster4-waguri.png", title: "Poster Produk", desc: "Bold headline & hierarchy jelas" },
    { image: "portfolio/poster/poster5-samuraix.png", title: "Poster Produk", desc: "Bold headline & hierarchy jelas" },
    { image: "portfolio/poster/poster6-burger.png", title: "Poster Produk", desc: "Bold headline & hierarchy jelas" },
    { image: "portfolio/poster/poster7-shawarma.png", title: "Poster Produk", desc: "Bold headline & hierarchy jelas" },
    { image: "portfolio/poster/poster8-bubur.png", title: "Poster Produk", desc: "Bold headline & hierarchy jelas" },
    { image: "portfolio/poster/poster9-jasadesain.png", title: "Poster Produk", desc: "Bold headline & hierarchy jelas" },
    { image: "portfolio/poster/poster10-koperasi.png", title: "Poster Produk", desc: "Bold headline & hierarchy jelas" },
    { image: "portfolio/poster/poster11-menuesteh.png", title: "Poster Produk", desc: "Bold headline & hierarchy jelas" },
  ],

  jacket: [
    { image: "portfolio/jacket/jacket1.png", title: "Jacket Design Rectoverso", desc: "Perpaduan biru dan putih" },
    { image: "portfolio/jacket/jacket2.png", title: "Jacket Design Rectoverso 2", desc: "Clean, corporate, timeless" },
    { image: "portfolio/jacket/jacket3.png", title: "Jacket Design Rectoverso 2", desc: "Clean, corporate, timeless" },
    { image: "portfolio/jacket/jacket4.png", title: "Jacket Design Rectoverso 2", desc: "Clean, corporate, timeless" },
    { image: "portfolio/jacket/ComingSoon", title: "Coming Soon", desc: "Clean, corporate, timeless" },
  ],

  cover: [
    { image: "portfolio/cover/covernovel1.jpg", title: "Cover Buku", desc: "Komposisi visual & storytelling" },
    { image: "portfolio/cover/covernovel2.jpg", title: "Novel Cover", desc: "Mood gelap & elegan" },
    { image: "portfolio/cover/covernovel3.jpg", title: "Novel Cover", desc: "Mood gelap & elegan" },
    { image: "portfolio/cover/covernovel4.jpg", title: "Novel Cover", desc: "Mood gelap & elegan" },
  ],

  feed: [
    { image: "portfolio/feed/feed1.png", title: "Feed Instagram", desc: "Identitas visual modern & minimal" },
    { image: "portfolio/feed/feed2.png", title: "Feed Instagram", desc: "Clean, corporate, timeless" },
    { image: "portfolio/feed/feed3.png", title: "Feed Instagram", desc: "Clean, corporate, timeless" },
    { image: "portfolio/feed/feed4.png", title: "Feed Instagram", desc: "Clean, corporate, timeless" },
    { image: "portfolio/feed/feed5.png", title: "Feed Instagram", desc: "Clean, corporate, timeless" },
  ],
};