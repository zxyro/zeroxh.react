/* ===============================
   STATIC DATA
================================ */
const SERVICES = [
  { title: "Logo Design", description: "Identitas brand profesional & eksklusif" },
  { title: "Poster Design", description: "Konten visual siap promosi" },
  { title: "UI/UX Design", description: "Modern, rapi, dan user friendly" },
  { title: "Cover Design", description: "Desain modern, menarik, dan eksklusif" },
];