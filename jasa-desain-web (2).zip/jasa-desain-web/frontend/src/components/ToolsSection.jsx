import { useEffect, useRef, useState } from "react";
import "../styles/tools.css";

const TOOLS = [
  {
    name: "Alight Motion",
    level: 80,
    core: true,
    logo: "tools/alightmotion.png",
  },
  {
    name: "Canva",
    level: 70,
    logo: "tools/canva.png",
  },
  {
    name: "Pixellab",
    level: 65,
    logo: "tools/pixellab.png",
  },
  {
    name: "ibis Paint X",
    level: 60,
    logo: "tools/ibispaintx.png",
  },
  {
    name: "Figma",
    level: 45,
    logo: "tools/figma.png",
  },
  {
    name: "Photoshop",
    level: 40,
    logo: "tools/photoshop.png",
  },
];

export default function ToolsSection() {
  const sectionRef = useRef(null);
  const [active, setActive] = useState(false);

  /* OBSERVER */
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => entry.isIntersecting && setActive(true),
      { threshold: 0.4 }
    );

    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="tools-section">
      <div className="tools-inner">

        {/* HEADER */}
        <div className="tools-header">
          <h2>Tools I Work With</h2>
          <p>Focused tools, honest skill levels, consistent results</p>
        </div>

        <div className="tools-grid">

          {/* CORE TOOL */}
          {TOOLS.filter(t => t.core).map(tool => (
            <div key={tool.name} className="tool-card core">
              <div className="tool-top">
                <div className="tool-left">
                  <img src={tool.logo} alt={tool.name} />
                  <span className="tool-name">{tool.name}</span>
                </div>
                <span className="tool-tag">Primary</span>
              </div>

              <div className="progress">
                <div
                  className={`progress-fill ${active ? "fill" : ""}`}
                  style={{ "--level": `${tool.level}%` }}
                />
              </div>

              <span className="tool-level">{tool.level}% proficiency</span>
            </div>
          ))}

          {/* SUPPORTING */}
          <div className="tool-support">
            {TOOLS.filter(t => !t.core).map((tool, i) => (
              <div
                key={tool.name}
                className="tool-card"
                style={{ transitionDelay: `${i * 60}ms` }}
              >
                <div className="tool-top">
                  <div className="tool-left">
                    <img src={tool.logo} alt={tool.name} />
                    <span className="tool-name">{tool.name}</span>
                  </div>
                  <span className="tool-level">{tool.level}%</span>
                </div>

                <div className="progress small">
                  <div
                    className={`progress-fill ${active ? "fill" : ""}`}
                    style={{ "--level": `${tool.level}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

        </div>

        <div className="tools-foot">
          <span>Clarity over complexity. Tools are just instruments.</span>
        </div>

      </div>
    </section>
  );
}