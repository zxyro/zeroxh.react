import "./footer.css"; 

export default function Footer() {
  return (
    <footer className="bg-primary-blue text-white py-12 px-6 md:px-16 text-center">
      <p>&copy; Zeroxh Graphic Design. All Rights Reserved.</p>
    </footer>
  );
}
