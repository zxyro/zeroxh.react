import { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { scrollToSection } from "../../utils/scroll";
import { useCart } from "../../context/CartContext";
import { useAuth } from "../../context/AuthContext";
import "./navbar.css";

export default function Navbar({ onOpenCart }) {
  const { totalQty } = useCart();
  const { user, isLoggedIn, loginWithGoogle, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [menuOpen, setMenuOpen] = useState(false);

  const isActive = (id) => {
    if (location.pathname !== "/") return false;
    return window.location.hash === `#${id}`;
  };

  const handleNav = (id) => {
    scrollToSection(id, navigate, location);
    setMenuOpen(false);
  };

  return (
    <nav className="navbar">
      <div className="navbar-inner">
        {/* LOGO */}
        <div
          className="navbar-logo"
          onClick={() => handleNav("hero")}
        >
          <span className="logo-main">ZeroX</span>
          <span className="logo-sub">Hikaru</span>
        </div>

        {/* DESKTOP MENU */}
        <div className="navbar-menu">
          <button
            className={isActive("hero") ? "active" : ""}
            onClick={() => handleNav("hero")}
          >
            Home
          </button>

          <button
            className={isActive("portfolio") ? "active" : ""}
            onClick={() => handleNav("portfolio")}
          >
            Portfolio
          </button>

          <button onClick={() => navigate("/whyus")}>
            WhyUs
          </button>

          {/* CART */}
          <button
            className="cart-icon"
            onClick={onOpenCart}
            aria-label="Keranjang"
          >
            <svg
              width="22"
              height="22"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M6 2l1.5 4h9L18 2" />
              <path d="M3 6h18l-2 13H5L3 6z" />
            </svg>
            {totalQty > 0 && (
              <span className="cart-badge">{totalQty}</span>
            )}
          </button>

          {/* LOGIN */}
          {!isLoggedIn ? (
            <button
              className="auth-guest"
              onClick={loginWithGoogle}
              title="Login dengan Google"
            >
              ?
            </button>
          ) : (
            <div className="auth-user">
              <img
                src={user.photoURL}
                alt={user.name}
                className="auth-avatar"
              />
              <div className="auth-dropdown">
                <button onClick={() => navigate("/voucher")}>
                  Voucher
                </button>
                <button onClick={() => navigate("/order-status")}>
                  Order Status
                </button>
                <button onClick={logout}>Logout</button>
              </div>
            </div>
          )}
        </div>

        {/* MOBILE TOGGLE */}
        <button
          className="menu-toggle"
          onClick={() => setMenuOpen((v) => !v)}
          aria-label="Menu"
        >
          <span />
          <span />
          <span />
        </button>
      </div>

      {/* MOBILE MENU */}
      <div className={`mobile-menu ${menuOpen ? "open" : ""}`}>
        <button onClick={() => handleNav("hero")}>Home</button>
        <button onClick={() => handleNav("portfolio")}>Portfolio</button>
        <button onClick={() => navigate("/whyus")}>WhyUs</button>

        {!isLoggedIn ? (
          <button onClick={loginWithGoogle}>
            Login
          </button>
        ) : (
          <>
            <button onClick={() => navigate("/voucher")}>
              Voucher
            </button>
            <button onClick={() => navigate("/order-status")}>
              Order Status
            </button>
            <button onClick={logout}>Logout</button>
          </>
        )}
      </div>
    </nav>
  );
}