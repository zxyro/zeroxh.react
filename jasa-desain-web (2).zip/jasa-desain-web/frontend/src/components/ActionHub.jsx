import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import {
  Sparkles,
  HelpCircle,
  TicketPercent,
  PackageSearch,
  MessageCircle,
} from "lucide-react";

export default function ActionHub() {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  if (location.pathname === "/checkout") return null;

  const scrollToSection = (id) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
    setOpen(false);
  };

  return (
    <div className={`action-hub ${open ? "open" : ""}`}>

      {/* ACTION ITEMS */}
      <div className="action-items">

        {/* BANTUAN */}
        <button
          className="action-item"
          data-tooltip="Bantuan"
          onClick={() => scrollToSection("contact")}
        >
          <HelpCircle size={18} />
        </button>

        {/* VOUCHER */}
        <button
          className="action-item"
          data-tooltip="Voucher"
          onClick={() => scrollToSection("services")}
        >
          <TicketPercent size={18} />
        </button>

        {/* STATUS ORDER */}
        <button
          className="action-item"
          data-tooltip="Status Order"
          onClick={() => {
            setOpen(false);
            navigate("/order-status");
          }}
        >
          <PackageSearch size={18} />
        </button>

        {/* CHAT ADMIN */}
        <a
          href="https://wa.me/6285173305799"
          target="_blank"
          rel="noreferrer"
          className="action-item"
          data-tooltip="Chat Admin"
          onClick={() => setOpen(false)}
        >
          <MessageCircle size={18} />
        </a>

      </div>

      {/* TOMBOL ACTION */}
      <button
        className="action-main"
        onClick={() => setOpen(v => !v)}
        aria-label="Menu"
      >
        <Sparkles size={22} />
      </button>

    </div>
  );
}