export default function Portfolio() {
  const items = [
    { img: "/assets/portfolio1.jpg", title: "Poster Event" },
    { img: "/assets/portfolio2.jpg", title: "Logo Brand" },
    { img: "/assets/portfolio3.jpg", title: "UI/UX Website" },
  ];

  return (
    <section id="portfolio" className="py-20 px-6 md:px-16 bg-white">
      <h2 className="text-3xl text-center font-semibold text-primary-blue mb-12">Portfolio Kami</h2>
      <div className="group">
  <img src="/assets/portfolio1.jpg" className="hover-scale" />
</div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 max-w-screen-xl mx-auto">
  {items.map((item, i) => (
    <div key={i} className="group overflow-hidden rounded-xl shadow-lg hover:shadow-xl transition-transform transform hover:scale-105">
      <img src={item.img} alt={item.title} className="w-full h-64 object-cover"/>
      <div className="bg-white p-4 text-center font-semibold text-primary-blue">
        {item.title}
      </div>
    </div>
  ))}
</div>
    </section>
  );
}
