import Navbar from "../components/Navbar";
import Hero from "../components/Hero";
import Portfolio from "../components/Portfolio";
import Footer from "../components/Footer";

export default function Landing({ showUI }) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-300 to-white overflow-x-hidden">
      {!showUI ? (
        <div className="flex items-center justify-center h-screen">
          <video
            src="/src/assets/intro.mp4"
            autoPlay
            muted
            className="w-full max-w-md md:max-w-lg rounded-xl shadow-xl"
          />
        </div>
      ) : (
        <>
          <Navbar />
          <Hero />
          <Portfolio />
          <Footer />
        </>
      )}
    </div>
  );
}
