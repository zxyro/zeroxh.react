import { useEffect } from "react";
import Pricing from "./Pricing";
import "../styles/whyus.css";

export default function WhyUs() {
  useEffect(() => {
    const reveals = document.querySelectorAll(".reveal");

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("active");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15 }
    );

    reveals.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <main className="whyus-article">

      <section className="article-hero reveal">
        <h1>
          Bukan studio besar.  
          Tapi serius soal hasil.
        </h1>
        <p>
          ZeroX Hikaru adalah layanan desain grafis independen
          yang berfokus pada kejelasan visual, proses yang rapi,
          dan komunikasi yang jujur.
        </p>
      </section>

      <section className="article-body">

        <article className="article-block reveal">
          <h2>Desain bukan soal ramai</h2>
          <p>
            Banyak desain terlihat menarik di awal,
            tapi gagal menyampaikan pesan.
            Di ZeroX Hikaru, desain diperlakukan sebagai alat komunikasi,
            bukan sekadar hiasan.
          </p>
          <p>
            Setiap elemen visual punya fungsi.
            Tidak ada ornamen yang dipasang hanya
            karena terlihat “keren”.
          </p>
        </article>

        <article className="article-block reveal">
          <h2>Kenapa desain yang rapi terasa lebih mahal?</h2>
          <p>
            Desain yang rapi menciptakan kepercayaan.
            Spasi yang konsisten, warna yang terkendali,
            dan tipografi yang jelas membuat brand terlihat
            lebih profesional, meskipun tanpa efek berlebihan.
          </p>
          <p>
            Inilah alasan ZeroX Hikaru memilih pendekatan
            <em> simple, clean, dan terarah</em>.
          </p>
        </article>

        <article className="article-block reveal">
          <h2>Pemula, tapi tidak asal</h2>
          <p>
            ZeroX Hikaru tidak mengklaim sebagai studio besar
            atau desainer senior.
            Tapi setiap project dikerjakan dengan disiplin,
            tanggung jawab, dan komitmen menyelesaikan pekerjaan
            sesuai kesepakatan.
          </p>
          <p>
            Kamu akan tahu apa yang sedang dikerjakan,
            progresnya bagaimana, dan kapan selesai.
          </p>
        </article>

        <article className="article-block reveal">
          <h2>Sedikit edukasi: desain yang baik itu…</h2>
          <ul>
            <li>✔ Mudah dipahami dalam 3 detik pertama</li>
            <li>✔ Konsisten dengan karakter brand</li>
            <li>✔ Tidak membingungkan mata</li>
            <li>✔ Tetap relevan saat dilihat berulang kali</li>
          </ul>
          <p>
            Desain yang baik tidak perlu menjelaskan dirinya sendiri.
            Pesannya langsung sampai.
          </p>
        </article>

      </section>

      <section className="article-cta reveal">
        <div className="cta-box">
          <h2>Punya ide atau kebutuhan desain?</h2>
          <p>
            Kita bahas dengan tenang dan jelas.
            Tidak ada paksaan order,
            tidak ada janji berlebihan.
          </p>

          <a
            href="https://wa.me/6285173305799"
            target="_blank"
            rel="noopener noreferrer"
            className="cta-btn"
          >
            Mulai Diskusi
          </a>

          <span className="cta-note">
            Respon manual • Bukan bot • Fokus solusi
          </span>
        </div>
      </section>

    </main>
  );
}