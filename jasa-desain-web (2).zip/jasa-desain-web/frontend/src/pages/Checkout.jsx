import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useCart } from "../context/CartContext";
import { saveOrder } from "../utils/orderStorage";
import { getVoucherByCode } from "../utils/voucherStorage";
import "../styles/checkout.css";

export default function Checkout() {
  const navigate = useNavigate();
  const {
    items,
    updateQty,
    updateRequestNote,
    subtotal,
    discountAmount,
    finalPrice,
    voucher,
    voucherError,
    applyVoucher,
    removeVoucher,
    clearCart,
  } = useCart();

  const [paymentMethod, setPaymentMethod] = useState("");
  const [orderData, setOrderData] = useState(null);

  // ================= ORDER ID =================
  function generateOrderId() {
    const date = new Date()
      .toISOString()
      .slice(0, 10)
      .replace(/-/g, "");
    const rand = Math.floor(1000 + Math.random() * 9000);
    return `ZX-${date}-${rand}`;
  }

  // ================= CREATE ORDER =================
  function handleCreateOrder() {
  if (!paymentMethod || items.length === 0) return;

  const order = {
    id: generateOrderId(),
    items,
    subtotal: subtotal(),
    discount: discountAmount(),
    total: finalPrice(),
    paymentMethod,
    status: "PENDING_PAYMENT",
    createdAt: new Date().toISOString(),
  };

  saveOrder(order); // 🔥 SIMPAN KE LOCAL STORAGE
  setOrderData(order);
  clearCart();
}

  // ================= PAYMENT INSTRUCTION =================
  if (orderData) {
    return (
      <section className="checkout-page">
        <div className="payment-result">
          <h1>Selesaikan Pembayaran</h1>

          <div className="order-box">
            <p><b>Order ID</b>: {orderData.id}</p>
            <p><b>Metode Pembayaran</b>: {orderData.paymentMethod}</p>
            <p><b>Total</b>: Rp {orderData.total.toLocaleString("id-ID")}</p>
            <p className="status pending">Status: Menunggu Pembayaran</p>
          </div>

          <div className="payment-instruction">
            <h3>Instruksi Pembayaran</h3>
            <p>
              Silakan lakukan pembayaran sesuai metode yang dipilih.
              Setelah pembayaran dikonfirmasi, desain akan segera diproses.
            </p>
            <p className="hint">
              *Admin akan memverifikasi pembayaran secara manual.
            </p>
          </div>

          <button
            className="secondary-btn"
            onClick={() => navigate("/order-status")}
          >
            Cek Status Pesanan
          </button>
        </div>
      </section>
    );
  }

  // ================= CHECKOUT FORM =================
  return (
    <section className="checkout-page">
      <header className="checkout-header">
        <button onClick={() => navigate("/")}>← Kembali</button>
        <h1>Checkout</h1>
      </header>

      <div className="checkout-layout">
        {/* ITEMS */}
        <div className="checkout-items">
          {items.map((item) => (
            <div key={item.id} className="checkout-card">
              <div>
                <h3>{item.service}</h3>
                <span className="badge">{item.package}</span>
                <p>Rp {item.price.toLocaleString("id-ID")}</p>

                <div className="qty">
                  <button
                    disabled={item.qty === 1}
                    onClick={() => updateQty(item.id, item.qty - 1)}
                  >−</button>
                  <span>{item.qty}</span>
                  <button
                    onClick={() => updateQty(item.id, item.qty + 1)}
                  >+</button>
                </div>

                <textarea
                  placeholder="Catatan untuk desainer (opsional)"
                  value={item.requestNote}
                  onChange={(e) =>
                    updateRequestNote(item.id, e.target.value)
                  }
                />
              </div>
            </div>
          ))}
        </div>

        {/* SUMMARY */}
        <aside className="checkout-summary">
          <h2>Ringkasan</h2>

          <div className="row">
            <span>Subtotal</span>
            <strong>Rp {subtotal().toLocaleString("id-ID")}</strong>
          </div>

          {voucher && (
            <div className="row discount">
              <span>Voucher ({voucher.code})</span>
              <strong>
                − Rp {discountAmount().toLocaleString("id-ID")}
              </strong>
            </div>
          )}

          <div className="row total">
            <span>Total</span>
            <strong>Rp {finalPrice().toLocaleString("id-ID")}</strong>
          </div>

          {/* VOUCHER */}
          <div className="voucher">
            {!voucher ? (
              <>
                <input
                  placeholder="Kode voucher"
                  onChange={(e) => applyVoucher(e.target.value)}
                />
                {voucherError && <small>{voucherError}</small>}
              </>
            ) : (
              <button onClick={removeVoucher}>Hapus Voucher</button>
            )}
          </div>

          {/* PAYMENT METHOD */}
          <div className="payment-method">
            <h3>Metode Pembayaran</h3>

            {["BCA Virtual Account", "Transfer Manual", "E-Wallet"].map(
              (method) => (
                <label key={method}>
                  <input
                    type="radio"
                    name="payment"
                    value={method}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                  />
                  {method}
                </label>
              )
            )}
          </div>

          <button
            className="primary-btn"
            disabled={!paymentMethod}
            onClick={handleCreateOrder}
          >
            Bayar Sekarang
          </button>
        </aside>
      </div>
    </section>
  );
}