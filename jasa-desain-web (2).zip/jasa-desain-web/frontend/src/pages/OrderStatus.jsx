import { useState } from "react";
import { PackageSearch } from "lucide-react";
import { getOrderById } from "../utils/orderStorage";
import "../styles/order-status.css";

export default function OrderStatus() {
  const [orderId, setOrderId] = useState("");
  const [order, setOrder] = useState(null);
  const [error, setError] = useState("");

  function handleCheckStatus() {
    if (!orderId) return;

    const result = getOrderById(orderId.trim());
    if (!result) {
      setOrder(null);
      setError("Kode pesanan tidak ditemukan.");
      return;
    }

    setError("");
    setOrder(result);
  }

  return (
    <section className="order-status-page">
      <div className="order-status-card">

        <div className="icon">
          <PackageSearch size={28} />
        </div>

        <h1>Status Pesanan</h1>
        <p className="desc">
          Masukkan kode pesanan untuk melihat progres desain.
        </p>

        <div className="order-input">
          <input
            type="text"
            placeholder="Contoh: ZX-20260209-4821"
            value={orderId}
            onChange={(e) => setOrderId(e.target.value)}
          />
          <button onClick={handleCheckStatus}>
            Cek Status
          </button>
        </div>

        {error && <p className="error">{error}</p>}

        {order && (
          <div className="order-result">
            <div className={`status-badge ${order.status.toLowerCase()}`}>
              {order.status === "PENDING_PAYMENT" && "Menunggu Pembayaran"}
              {order.status === "IN_PROGRESS" && "Dalam Proses"}
              {order.status === "DONE" && "Selesai"}
            </div>

            <ul>
              <li><b>Order ID:</b> {order.id}</li>
              <li><b>Metode Pembayaran:</b> {order.paymentMethod}</li>
              <li><b>Total:</b> Rp {order.total.toLocaleString("id-ID")}</li>
              <li>
                <b>Tanggal:</b>{" "}
                {new Date(order.createdAt).toLocaleString("id-ID")}
              </li>
            </ul>

            <p className="note">
              *Jika status masih menunggu pembayaran, silakan selesaikan pembayaran.
              Admin akan memverifikasi secara manual.
            </p>
          </div>
        )}

      </div>
    </section>
  );
}