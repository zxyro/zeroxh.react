import { useState } from "react";
import { getOrderById, updateOrderStatus } from "../utils/orderStorage";
import "../styles/admin-order.css";

export default function AdminOrderPanel() {
  const [orderId, setOrderId] = useState("");
  const [order, setOrder] = useState(null);
  const [error, setError] = useState("");

  function handleFindOrder() {
    if (!orderId) return;

    const data = getOrderById(orderId.trim());
    if (!data) {
      setError("Order tidak ditemukan");
      setOrder(null);
      return;
    }

    setError("");
    setOrder(data);
  }

  function handleUpdate(status) {
    updateOrderStatus(order.id, status);
    setOrder({ ...order, status });
  }

  return (
    <section className="admin-page">
      <div className="admin-card">
        <h1>Admin Order Panel</h1>

        <input
          placeholder="Masukkan Order ID"
          value={orderId}
          onChange={(e) => setOrderId(e.target.value)}
        />

        <button onClick={handleFindOrder}>Cari Order</button>

        {error && <p className="error">{error}</p>}

        {order && (
          <div className="admin-order-box">
            <p><b>ID:</b> {order.id}</p>
            <p><b>Status:</b> {order.status}</p>
            <p><b>Total:</b> Rp {order.total.toLocaleString("id-ID")}</p>

            <div className="admin-actions">
              {order.status === "PENDING_PAYMENT" && (
                <button
                  className="verify"
                  onClick={() => handleUpdate("IN_PROGRESS")}
                >
                  Verifikasi Pembayaran
                </button>
              )}

              {order.status === "IN_PROGRESS" && (
                <button
                  className="done"
                  onClick={() => handleUpdate("DONE")}
                >
                  Tandai Selesai
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}