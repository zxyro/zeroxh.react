import { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";

/* ===============================
   SECTIONS (PAGE LEVEL)
================================ */
import HeroSection from "../sections/home/Hero/HeroSection";
import ServicesSection from "../features//services/ServiceSection";
import PortfolioSection from "../features/portfolio/PortfolioSection";
import ToolsSection from "../components/ToolsSection";

import "../styles/home.css";

export default function Home() {
  const navigate = useNavigate();
  const location = useLocation();

  /* ===============================
     SCROLL HANDLER
  ================================ */
  const scrollToSection = (id) => {
    if (location.pathname !== "/") {
      navigate("/");
      setTimeout(() => {
        document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
      }, 150);
    } else {
      document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <main className="home-page">
      {/* HERO */}
      <HeroSection
        onCTAPrimary={() => scrollToSection("services")}
        onCTASecondary={() => scrollToSection("portfolio")}
      />

      {/* SERVICES */}
      <ServicesSection />

      {/* TOOLS */}
      <ToolsSection />

      {/* PORTFOLIO */}
      <PortfolioSection />
    </main>
  );
}