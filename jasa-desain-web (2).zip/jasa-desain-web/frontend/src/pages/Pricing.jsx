import "../index.css";

export default function Pricing() {
  return (
    <section className="pricing">
      <div className="pricing-head reveal">
        <h2>
          Harga yang Masuk Akal, <br />
          untuk <span>Desain yang Tepat</span>
        </h2>
        <p>
          Saya tidak menjual desain mahal.  
          Saya menjual desain yang bekerja.
        </p>
      </div>

      <div className="pricing-grid">

        {/* CARD 1 */}
        <div className="pricing-card reveal">
          <h3>Desain Sekali Jalan</h3>
          <ul>
            <li>Logo</li>
            <li>Poster</li>
            <li>Konten media sosial</li>
          </ul>

          <div className="price">
            Mulai dari <strong>Rp XX.000</strong>
          </div>

          <span className="note">
            Cocok untuk UMKM & personal brand
          </span>
        </div>

        {/* CARD 2 */}
        <div className="pricing-card highlight reveal">
          <h3>Visual Konsisten</h3>
          <ul>
            <li>Beberapa aset desain</li>
            <li>Konsistensi warna & layout</li>
            <li>Lebih dari satu output</li>
          </ul>

          <div className="price">
            Harga <strong>Disesuaikan</strong>
          </div>

          <span className="note">
            Untuk brand yang mau rapi & serius
          </span>
        </div>

        {/* CARD 3 */}
        <div className="pricing-card reveal">
          <h3>Motion & Konten Dinamis</h3>
          <ul>
            <li>Spesialis Alight Motion</li>
            <li>Motion simpel & komunikatif</li>
            <li>Fokus pesan, bukan efek</li>
          </ul>

          <div className="price">
            Berdasarkan <strong>Durasi & Kompleksitas</strong>
          </div>

          <span className="note">
            Cocok untuk konten modern & clean
          </span>
        </div>

      </div>

      <div className="pricing-footer reveal">
        <p className="disclaimer">
          Harga final ditentukan dari kebutuhan,  
          bukan dari ego desain.
        </p>

        <button className="pricing-cta">
          Diskusi dulu, tanpa komitmen
        </button>
      </div>
    </section>
  );
}