import {
  AVAILABLE_VOUCHERS,
  claimVoucher,
  getClaimedVouchers,
} from "../utils/voucherStorage";

import "../styles/voucher.css";

export default function Voucher() {
  const claimed = getClaimedVouchers();

  const handleClaim = (voucherCode) => {
    const success = claimVoucher(voucherCode);
    if (success) {
      window.location.reload();
    }
  };

  return (
    <section className="voucher-page">
      <header className="voucher-header">
        <h1>Voucher Promo</h1>
        <p>Klaim voucher dan gunakan saat checkout</p>
      </header>

      <div className="voucher-grid">
        {AVAILABLE_VOUCHERS.map((v) => {
          const isClaimed = claimed.includes(v.code);

          return (
            <div key={v.code} className="voucher-card">
              <div>
                <h3>{v.code}</h3>
                <p>{v.desc}</p>
                <span className="discount">
                  − Rp {v.discount.toLocaleString("id-ID")}
                </span>
              </div>

              <button
                disabled={isClaimed}
                onClick={() => handleClaim(v.code)}
              >
                {isClaimed ? "Sudah Diklaim" : "Klaim Voucher"}
              </button>
            </div>
          );
        })}
      </div>

      <p className="note">
        *Voucher harus diklaim sebelum digunakan di checkout
      </p>
    </section>
  );
}