export default function OrderSummary({ items, total, onSubmit }) {
  return (
    <section className="checkout-card">
      <h2>Ringkasan Pesanan</h2>

      <ul className="order-list">
        {items.map((item, i) => (
          <li key={i}>
            <span>{item.title}</span>
            <strong>Rp{item.price.toLocaleString()}</strong>
          </li>
        ))}
      </ul>

      <div className="order-total">
        <span>Total</span>
        <strong>Rp{total.toLocaleString()}</strong>
      </div>

      <button className="checkout-submit" onClick={onSubmit}>
        Buat Pesanan
      </button>
    </section>
  );
}