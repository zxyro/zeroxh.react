export default function CheckoutForm({ value, onChange }) {
  return (
    <section className="checkout-card">
      <h2>Data Pemesan</h2>

      <label>
        Nama
        <input
          type="text"
          value={value.name}
          onChange={(e) =>
            onChange({ ...value, name: e.target.value })
          }
        />
      </label>

      <label>
        Kontak (WhatsApp / Email)
        <input
          type="text"
          value={value.contact}
          onChange={(e) =>
            onChange({ ...value, contact: e.target.value })
          }
        />
      </label>

      <label>
        Catatan Tambahan
        <textarea
          value={value.note}
          onChange={(e) =>
            onChange({ ...value, note: e.target.value })
          }
        />
      </label>
    </section>
  );
}