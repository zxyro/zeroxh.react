import { useNavigate, useLocation } from "react-router-dom";
import { useCart } from "../../context/CartContext";
import "./cart.css";

export default function CheckoutBar() {
  const { items, totalPrice } = useCart();
  const navigate = useNavigate();
  const location = useLocation();

  if (items.length === 0) return null;
  if (location.pathname === "/checkout") return null;

  return (
    <div className="checkout-bar">
      <div className="checkout-container">

        {/* INFO */}
        <div className="checkout-info">
          <span className="checkout-count">
            {items.length} Paket Dipilih
          </span>
          <span className="checkout-total">
            Rp {totalPrice().toLocaleString("id-ID")}
          </span>
        </div>

        {/* ACTION */}
        <button
          className="checkout-cta"
          onClick={() => navigate("/checkout")}
        >
          Lanjut ke Checkout
        </button>

      </div>
    </div>
  );
}