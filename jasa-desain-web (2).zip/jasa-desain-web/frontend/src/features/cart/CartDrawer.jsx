import { useCart } from "../../context/CartContext";
import { useNavigate } from "react-router-dom";
import "./cart.css"

export default function CartDrawer({ open, onClose, onCheckout }) {
  const { items, removeItem } = useCart();
  const navigate = useNavigate();

  return (
    <>
      {/* OVERLAY */}
      <div
        className={`cart-overlay ${open ? "open" : ""}`}
        onClick={onClose}
      />

      {/* DRAWER */}
      <aside className={`cart-drawer ${open ? "open" : ""}`}>
        {/* HEADER */}
        <div className="cart-header">
          <h3>Keranjang</h3>
          <button
            className="cart-close"
            onClick={onClose}
            aria-label="Tutup keranjang"
          >
            ✕
          </button>
        </div>

        {/* ITEMS */}
        <div className="cart-items">
          {items.length === 0 && (
            <p className="empty">Keranjang kosong</p>
          )}

          {items.map((item) => (
            <div key={item.id} className="cart-item">
              <div>
                <div className="cart-item-title">
                  {item.service}
                </div>
                <div className="cart-item-meta">
                  Paket: {item.package} • Qty {item.qty}
                </div>
              </div>

              <div className="cart-item-price">
                Rp {item.price.toLocaleString("id-ID")}
              </div>

              <button
                className="remove"
                onClick={() => removeItem(item.id)}
              >
                Hapus
              </button>
            </div>
          ))}
        </div>

        {/* FOOTER */}
        {items.length > 0 && (
          <div className="cart-footer">
            <div className="cart-total">
              <span>Total</span>
              <span>
                Rp{" "}
                {items
                  .reduce(
                    (sum, i) => sum + i.price * i.qty,
                    0
                  )
                  .toLocaleString("id-ID")}
              </span>
            </div>

            <button
              className="cart-checkout-btn"
              onClick={() => {
                onClose();
                navigate("/checkout");
              }}
            >
              Checkout
            </button>
          </div>
        )}
      </aside>
    </>
  );
}