import { useEffect, useState } from "react";
import PortfolioRow from "./PortfolioRow";
import PortfolioModal from "./PortfolioModal";

import "./portfolio.css";

/* ===============================
   PORTFOLIO DATA (REAL)
================================ */
const PORTFOLIO = {
  poster: {
    title: "Poster Design",
    ratio: "portrait",
    items: [
      {
        image: "portfolio/poster/poster1-nike.png",
        title: "Poster Event",
        desc: "Hierarchy jelas & fokus konversi",
      },
      {
        image: "portfolio/poster/poster2-kamenraider.png",
        title: "Poster Produk",
        desc: "Bold headline & visual kuat",
      },
      {
        image: "portfolio/poster/poster3-NewJeans.png",
        title: "Poster Produk",
        desc: "Bold headline & visual kuat",
      },
      {
        image: "portfolio/poster/poster4-waguri.png",
        title: "Poster Produk",
        desc: "Bold headline & visual kuat",
      },
      {
        image: "portfolio/poster/poster5-samuraix.png",
        title: "Poster Produk",
        desc: "Bold headline & visual kuat",
      },
      {
        image: "portfolio/poster/poster6-burger.png",
        title: "Poster Produk",
        desc: "Bold headline & visual kuat",
      },
    ],
  },

  jacket: {
    title: "Jacket Design",
    ratio: "portrait",
    items: [
      {
        image: "portfolio/jacket/jacket1.png",
        title: "Jacket Event",
        desc: "Hierarchy jelas & fokus konversi",
      },
      {
        image: "portfolio/jacket/jacket2.png",
        title: "Jacket Produk",
        desc: "Bold headline & visual kuat",
      },
      {
        image: "portfolio/jacket/jacket3.png",
        title: "Jacket Produk",
        desc: "Bold headline & visual kuat",
      },
      {
        image: "portfolio/jacket/jacket4.png",
        title: "Jacket Produk",
        desc: "Bold headline & visual kuat",
      },
      {
        image: "portfolio/jacket/jacket5.png",
        title: "Coming Soon",
        desc: "Coming Soon",
      },
    ],
  },

  cover: {
    title: "Book Cover",
    ratio: "landscape",
    items: [
      {
        image: "portfolio/cover/covernovel1.jpg",
        title: "Novel Cover",
        desc: "Mood gelap & elegan",
      },
      {
        image: "portfolio/cover/covernovel2.jpg",
        title: "Novel Cover",
        desc: "Storytelling visual",
      },
      {
        image: "portfolio/cover/covernovel3.jpg",
        title: "Novel Cover",
        desc: "Storytelling visual",
      },
      {
        image: "portfolio/cover/covernovel4.jpg",
        title: "Novel Cover",
        desc: "Storytelling visual",
      },
    ],
  },

  feed: {
    title: "Feed Instagram",
    ratio: "longsquare",
    items: [
      {
        image: "portfolio/feed/feed1.png",
        title: "Feed Branding",
        desc: "Visual konsisten & modern",
      },
      {
        image: "portfolio/feed/feed2.png",
        title: "Feed Branding",
        desc: "Visual konsisten & modern",
      },
      {
        image: "portfolio/feed/feed3.png",
        title: "Feed Branding",
        desc: "Visual konsisten & modern",
      },
      {
        image: "portfolio/feed/feed4.png",
        title: "Feed Branding",
        desc: "Visual konsisten & modern",
      },
      {
        image: "portfolio/feed/feed5.png",
        title: "Feed Branding",
        desc: "Visual konsisten & modern",
      },
    ],
  },
};

export default function PortfolioSection() {
  const [activeItem, setActiveItem] = useState(null);

  /* BODY LOCK */
  useEffect(() => {
    document.body.classList.toggle("detail-open", !!activeItem);
  }, [activeItem]);

  return (
    <section id="portfolio" className="portfolio-section">
      <h2 className="section-title center">
        Portfolio Terpilih
      </h2>

      {Object.values(PORTFOLIO).map((row) => (
        <PortfolioRow
          key={row.title}
          title={row.title}
          ratio={row.ratio}
          items={row.items}
          onClick={setActiveItem}
        />
      ))}

      {/* MODAL */}
      {activeItem && (
        <PortfolioModal
          item={activeItem}
          onClose={() => setActiveItem(null)}
        />
      )}
    </section>
  );
}