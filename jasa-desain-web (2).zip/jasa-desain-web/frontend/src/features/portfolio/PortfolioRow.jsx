import { useEffect, useRef } from "react";
import "../portfolio/portfolio.css"

export default function PortfolioRow({ title, items, ratio, onClick }) {
  const railRef = useRef(null);

  useEffect(() => {
    const el = railRef.current;
    let scroll;

    const start = () => {
      scroll = setInterval(() => {
        el.scrollLeft += 0.4;
      }, 16);
    };

    const stop = () => clearInterval(scroll);

    start();
    el.addEventListener("mouseenter", stop);
    el.addEventListener("mouseleave", start);

    return () => {
      stop();
      el.removeEventListener("mouseenter", stop);
      el.removeEventListener("mouseleave", start);
    };
  }, []);

  const scrollBy = (dir) => {
    railRef.current.scrollBy({ left: dir * 300, behavior: "smooth" });
  };

  return (
    <div className="portfolio-row">
      <h3 className="row-title">{title}</h3>

      <button className="arrow left" onClick={() => scrollBy(-1)}>‹</button>
      <button className="arrow right" onClick={() => scrollBy(1)}>›</button>

      <div className="portfolio-rail" ref={railRef}>
        {items.map((item, i) => (
          <div
            key={i}
            className={`portfolio-card ${ratio}`}
            onClick={() => onClick(item)}
          >
            <img src={item.image} alt={item.title} />
            <div className="overlay">
              <span>{item.title}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}8