import { useEffect } from "react";
import "./portfolio-modal.css";

export default function PortfolioModal({ item, onClose }) {
  /* ===============================
     ESC KEY CLOSE
  ================================ */
  useEffect(() => {
    const handleEsc = (e) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handleEsc);
    return () => window.removeEventListener("keydown", handleEsc);
  }, [onClose]);

  if (!item) return null;

  return (
    <div className="portfolio-modal-overlay" onClick={onClose}>
      <div
        className="portfolio-modal-card"
        onClick={(e) => e.stopPropagation()}
      >
        {/* IMAGE */}
        <div className="portfolio-modal-image">
          <img src={item.image} alt={item.title} />
        </div>

        {/* CONTENT */}
        <div className="portfolio-modal-content">
          <h3 className="portfolio-modal-title">
            {item.title}
          </h3>

          {item.desc && (
            <p className="portfolio-modal-desc">
              {item.desc}
            </p>
          )}

          {/* ACTION */}
          <button
            className="portfolio-modal-close"
            onClick={onClose}
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
}