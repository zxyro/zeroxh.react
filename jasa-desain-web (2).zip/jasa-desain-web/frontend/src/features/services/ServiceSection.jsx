import { useState } from "react";
import { useCart } from "../../context/CartContext";

import ServiceCard from "./ServiceCard";
import PackagePanel from "./PackagePanel";
import CheckoutBar from "../cart/CheckoutBar";

import "./serckage.css";

/* ===============================
   SERVICE DATA (REAL)
================================ */
const SERVICES = [
  {
    title: "Logo Design",
    description: "Identitas brand profesional & konsisten",
    target: "UMKM, Personal Brand",
    priceFrom: 150000,
  },
  {
    title: "Poster Design",
    description: "Visual promosi siap publish",
    target: "Event, Produk, Sosial Media",
    priceFrom: 100000,
  },
  {
    title: "UI/UX Design",
    description: "Tampilan modern & user friendly",
    target: "Website, Landing Page",
    priceFrom: 300000,
  },
  {
    title: "Cover Design",
    description: "Cover buku & konten digital",
    target: "Novel, Ebook, Sosial Media",
    priceFrom: 120000,
  },
];

export default function ServicesSection() {
  const { totalQty } = useCart();
  const [activeService, setActiveService] = useState(null);

  return (
    <section id="services" className="services-section">
      <h2 className="section-title">Layanan Desain</h2>
      <p className="section-desc">
        Pilih layanan, tentukan paket, lalu lanjut ke checkout.
        Semua alurnya jelas dan transparan.
      </p>

      {/* SERVICE LIST */}
      <div className="services-grid">
        {SERVICES.map((service) => (
          <ServiceCard
            key={service.title}
            title={service.title}
            description={service.description}
            target={service.target}
            priceFrom={service.priceFrom}
            active={activeService === service.title}
            onClick={() =>
              setActiveService((prev) =>
                prev === service.title ? null : service.title
              )
            }
          />
        ))}
      </div>

      {/* EXPANDED PACKAGE */}
      {activeService && (
        <div className="service-expand">
          <PackagePanel
            service={activeService}
            onClose={() => setActiveService(null)}
          />
        </div>
      )}

      {/* FLOATING CHECKOUT */}
      {totalQty > 0 && <CheckoutBar />}
    </section>
  );
}