import "../services/serckage.css";

export default function ServiceCard({
  title,
  description,
  priceFrom,
  target,
  active,
  onClick,
}) {
  const formattedPrice =
    typeof priceFrom === "number"
      ? `Rp ${priceFrom.toLocaleString("id-ID")}`
      : null;

  return (
    <div
      className={`service-card ${active ? "active" : ""}`}
      onClick={onClick}
    >
      <div className="service-card-inner">

        {/* INFO */}
        <div className="service-info">
          <h3 className="service-title">{title}</h3>

          <p className="service-desc">{description}</p>

          {target && (
            <p className="service-target">
              Cocok untuk <span>{target}</span>
            </p>
          )}
        </div>

        {/* META / CTA */}
        <div className="service-meta">
          {formattedPrice && (
            <div className="service-price">
              <span className="price-label">Mulai dari</span>
              <strong className="price-value">{formattedPrice}</strong>
            </div>
          )}

          <button className="service-cta">
            {active ? "Tutup Paket" : "Lihat Paket"}
          </button>
        </div>

      </div>
    </div>
  );
}