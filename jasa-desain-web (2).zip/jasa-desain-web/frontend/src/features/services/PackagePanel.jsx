import { useState } from "react";
import { useCart } from "../../context/CartContext";
import "../services/serckage.css";

const PACKAGES = [
  {
    id: "hemat",
    name: "Hemat",
    price: 150000,
    estimate: "2–3 hari",
    desc: "Desain rapi & fungsional untuk kebutuhan cepat.",
    highlight: "Cocok untuk kebutuhan simpel",
  },
  {
    id: "rekomendasi",
    name: "Rekomendasi",
    price: 300000,
    estimate: "3–4 hari",
    desc: "Balance visual & konsep. Paling sering dipilih klien.",
    highlight: "Paling populer",
    recommended: true,
  },
  {
    id: "profesional",
    name: "Profesional",
    price: 550000,
    estimate: "4–6 hari",
    desc: "Eksplorasi desain lebih dalam & detail maksimal.",
    highlight: "Hasil paling maksimal",
  },
];

export default function PackagePanel({ service, onClose }) {
  const { addItem } = useCart();
  const [loading, setLoading] = useState(null);
  const [voucherApplied, setVoucherApplied] = useState(false);

  const handleAdd = (pkg) => {
    if (loading) return;

    setLoading(pkg.id);

    setTimeout(() => {
      addItem({
        service,
        package: pkg.name,
        price: pkg.price,
        qty: 1,
        estimate: pkg.estimate,
        voucher: voucherApplied ? "NEWCLIENT50" : null,
      });

      setLoading(null);
      onClose?.();
    }, 400);
  };

  return (
    <div className="package-panel">

      {/* HEADER */}
      <div className="package-header">
        <div className="package-head-text">
          <h3>Paket {service}</h3>
          <p>
            Pilih paket sesuai kebutuhan. Harga transparan,
            tanpa biaya tersembunyi.
          </p>
        </div>

        <button className="package-close" onClick={onClose}>
          Tutup
        </button>
      </div>

      {/* PACKAGES */}
      <div className="package-grid">
        {PACKAGES.map((pkg) => (
          <div
            key={pkg.id}
            className={`package-card ${
              pkg.recommended ? "recommended" : ""
            }`}
          >
            {pkg.recommended && (
              <div className="package-badge">
                Rekomendasi
              </div>
            )}

            <h4 className="package-title">{pkg.name}</h4>

            <p className="package-desc">{pkg.desc}</p>

            <span className="package-highlight">
              {pkg.highlight}
            </span>

            <div className="package-meta">
              <span className="package-estimate">
                Estimasi {pkg.estimate}
              </span>

              <div className="package-price">
                Rp {pkg.price.toLocaleString("id-ID")}
              </div>
            </div>

            <button
              className="package-btn"
              disabled={loading}
              onClick={() => handleAdd(pkg)}
            >
              {loading === pkg.id
                ? "Menambahkan..."
                : "Pilih Paket"}
            </button>
          </div>
        ))}
      </div>

      {/* VOUCHER */}
      <div className={`voucher-box ${voucherApplied ? "active" : ""}`}>
        <div className="voucher-info">
          <h4>Voucher Klien Baru</h4>
          <p>
            Potongan langsung <strong>Rp50.000</strong> untuk
            pemesanan pertama.
          </p>
        </div>

        <button
          className="voucher-btn"
          onClick={() => setVoucherApplied(true)}
          disabled={voucherApplied}
        >
          {voucherApplied ? "Voucher Aktif" : "Ambil Voucher"}
        </button>
      </div>

    </div>
  );
}