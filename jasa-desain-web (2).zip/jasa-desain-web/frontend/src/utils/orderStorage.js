const STORAGE_KEY = "orders";

export function getOrders() {
  return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
}

export function saveOrder(order) {
  const orders = getOrders();
  orders.push(order);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(orders));
}

export function getOrderById(orderId) {
  const orders = getOrders();
  return orders.find((o) => o.id === orderId);
}

export function updateOrderStatus(orderId, status) {
  const orders = getOrders();
  const updated = orders.map((o) =>
    o.id === orderId ? { ...o, status } : o
  );

  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
}