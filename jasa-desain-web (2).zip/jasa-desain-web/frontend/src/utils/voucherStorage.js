export const AVAILABLE_VOUCHERS = [
  {
    code: "ZX90",
    discount: 90000,
    desc: "Potongan Rp90.000",
  },
  {
    code: "ZX55",
    discount: 55000,
    desc: "Potongan Rp55.000",
  },
];

export function getClaimedVouchers() {
  return JSON.parse(localStorage.getItem("claimedVouchers")) || [];
}

export function claimVoucher(code) {
  const claimed = getClaimedVouchers();
  if (claimed.includes(code)) return false;

  localStorage.setItem(
    "claimedVouchers",
    JSON.stringify([...claimed, code])
  );
  return true;
}

export function getVoucherByCode(code) {
  const claimed = getClaimedVouchers();
  if (!claimed.includes(code)) return null;

  return AVAILABLE_VOUCHERS.find((v) => v.code === code) || null;
}