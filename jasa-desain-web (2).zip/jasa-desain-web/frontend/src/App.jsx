import { Routes, Route, useLocation } from "react-router-dom";
import { useState } from "react";

import Home from "./pages/Home";
import Voucher from "./pages/Voucher";
import Checkout from "./pages/Checkout";
import OrderStatus from "./pages/OrderStatus";
import WhyUs from "./pages/WhyUs";
import AdminOrderPanel from "./pages/AdminOrderPanel";

import Navbar from "./components/Navbar/Navbar";
import CartDrawer from "./features/cart/CartDrawer";
import CheckoutBar from "./features/cart/CheckoutBar";
import ActionHub from "./components/ActionHub";

export default function App() {
  const [openCart, setOpenCart] = useState(false);
  const location = useLocation();

  const isCheckoutPage = location.pathname === "/checkout";

  return (
    <>
    
      <Navbar onOpenCart={() => setOpenCart(true)} />

      <CartDrawer
        open={openCart}
        onClose={() => setOpenCart(false)}
      />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/voucher" element={<Voucher />} />
        <Route path="/checkout" element={<Checkout />} />
        <Route path="/order-status" element={<OrderStatus />} />
        <Route path="/whyus" element={<WhyUs />} />
        <Route path="/admin/orders" element={<AdminOrderPanel />} />
      </Routes>

      {!isCheckoutPage && <ActionHub />}
      {!isCheckoutPage && <CheckoutBar />}
    </>
  );
}