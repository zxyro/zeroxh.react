router.post('/', auth, admin, create);
router.get('/', getAll);
router.put('/:id', auth, admin, update);
router.delete('/:id', auth, admin, remove);