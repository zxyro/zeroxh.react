router.post('/', auth, checkout);
router.post('/proof/:id', auth, upload.single('proof'), uploadProof);
router.put('/approve/:id', auth, admin, approve);