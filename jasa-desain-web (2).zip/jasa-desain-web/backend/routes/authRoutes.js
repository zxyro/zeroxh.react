router.post('/register', register);
router.post('/login', login);