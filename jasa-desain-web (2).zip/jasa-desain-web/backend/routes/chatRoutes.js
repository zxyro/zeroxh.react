router.post('/', auth, send);
router.get('/', auth, getChat);