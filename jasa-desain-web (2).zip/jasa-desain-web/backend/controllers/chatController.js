const db = require('../config/db');

exports.send = (req, res) => {
  const { receiver_id, message } = req.body;

  db.query(
    'INSERT INTO chats (sender_id, receiver_id, message) VALUES (?,?,?)',
    [req.user.id, receiver_id, message],
    () => res.json({ message: 'Message sent' })
  );
};

exports.getChat = (req, res) => {
  db.query(
    `SELECT * FROM chats 
     WHERE sender_id=? OR receiver_id=? 
     ORDER BY created_at`,
    [req.user.id, req.user.id],
    (err, result) => res.json(result)
  );
};
