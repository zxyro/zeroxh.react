const User = require('../models/User');
const bcrypt = require('bcryptjs');

exports.createUser = (req, res) => {
  const { name, email, password, role } = req.body;
  const hashedPassword = bcrypt.hashSync(password, 10);

  User.create({ name, email, password: hashedPassword, role }, (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ message: 'User created successfully', id: result.insertId });
  });
};

exports.getAllUsers = (req, res) => {
  User.findAll((err, results) => {
    if (err) return res.status(500).json({ error: err });
    res.json(results);
  });
};
 