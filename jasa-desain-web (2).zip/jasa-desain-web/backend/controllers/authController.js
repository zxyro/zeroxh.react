const db = require('../config/db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

exports.register = (req, res) => {
  const { name, email, password } = req.body;
  const hash = bcrypt.hashSync(password, 10);

  db.query(
    'INSERT INTO users (name, email, password, role) VALUES (?,?,?,?)',
    [name, email, hash, 'customer'],
    () => res.json({ message: 'Register success' })
  );
};

exports.login = (req, res) => {
  const { email, password } = req.body;

  db.query('SELECT * FROM users WHERE email=?', [email], (err, result) => {
    if (!result.length) return res.status(404).json({ message: 'User not found' });

    const user = result[0];
    if (!bcrypt.compareSync(password, user.password))
      return res.status(401).json({ message: 'Wrong password' });

    const token = jwt.sign(
      { id: user.id, role: user.role },
      'SECRET_KEY'
    );

    res.json({ token, role: user.role });
  });
};
