const db = require('../config/db');

exports.checkout = (req, res) => {
  const { product_id, total_price, payment_method, address } = req.body;

  db.query(
    `INSERT INTO transactions 
    (customer_id, product_id, total_price, payment_method, address)
    VALUES (?,?,?,?,?)`,
    [req.user.id, product_id, total_price, payment_method, address],
    () => res.json({ message: 'Checkout success' })
  );
};

exports.uploadProof = (req, res) => {
  db.query(
    'UPDATE transactions SET proof_of_payment=? WHERE id=?',
    [req.file.path, req.params.id],
    () => res.json({ message: 'Proof uploaded' })
  );
};

exports.approve = (req, res) => {
  db.query(
    'UPDATE transactions SET payment_status="paid" WHERE id=?',
    [req.params.id],
    () => res.json({ message: 'Payment approved' })
  );
};
