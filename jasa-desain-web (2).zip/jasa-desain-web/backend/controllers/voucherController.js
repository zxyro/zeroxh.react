const db = require('../config/db');

exports.create = (req, res) => {
  const { code, discount_percentage } = req.body;

  db.query(
    'INSERT INTO vouchers (code, discount_percentage, created_by) VALUES (?,?,?)',
    [code, discount_percentage, req.user.id],
    () => res.json({ message: 'Voucher created' })
  );
};

exports.getAll = (req, res) => {
  db.query('SELECT * FROM vouchers', (err, result) => res.json(result));
};
