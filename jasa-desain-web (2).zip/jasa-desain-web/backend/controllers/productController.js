const db = require('../config/db');

exports.create = (req, res) => {
  const { name, description, price, image_url } = req.body;

  db.query(
    'INSERT INTO products (name, description, price, image_url, created_by) VALUES (?,?,?,?,?)',
    [name, description, price, image_url, req.user.id],
    () => res.json({ message: 'Product created' })
  );
};

exports.getAll = (req, res) => {
  db.query('SELECT * FROM products', (err, result) => res.json(result));
};

exports.update = (req, res) => {
  const { name, description, price } = req.body;

  db.query(
    'UPDATE products SET name=?, description=?, price=? WHERE id=?',
    [name, description, price, req.params.id],
    () => res.json({ message: 'Product updated' })
  );
};

exports.remove = (req, res) => {
  db.query(
    'DELETE FROM products WHERE id=?',
    [req.params.id],
    () => res.json({ message: 'Product deleted' })
  );
};
