const db = require('../config/db');

const User = {
  create: (data, callback) => {
    const sql = `INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)`;
    db.query(sql, [data.name, data.email, data.password, data.role], callback);
  },

  findById: (id, callback) => {
    db.query(`SELECT * FROM users WHERE id = ?`, [id], callback);
  },

  findAll: (callback) => {
    db.query(`SELECT * FROM users`, callback);
  },

  update: (id, data, callback) => {
    const sql = `UPDATE users SET name = ?, email = ?, password = ?, role = ? WHERE id = ?`;
    db.query(sql, [data.name, data.email, data.password, data.role, id], callback);
  },

  delete: (id, callback) => {
    db.query(`DELETE FROM users WHERE id = ?`, [id], callback);
  },
};

module.exports = User;
